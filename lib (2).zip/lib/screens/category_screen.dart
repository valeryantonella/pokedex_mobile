import 'package:flutter/material.dart';
import 'package:pokedex_mobile/providers/category_provider.dart';
import 'package:pokedex_mobile/widgets/category_list.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  String lastUpdate = 'N/A';

  Future<void> updateLastSyncDate(String lastSync) async {
    final SharedPreferences sharedPref = await SharedPreferences.getInstance();
    await sharedPref.setString("last_sync", lastSync);
  }
  
  Future<String?> getLastSyncDate() async {
    final SharedPreferences sharedPref = await SharedPreferences.getInstance();
    return sharedPref.getString("last_sync");
  }

  @override
  void initState(){
    getLastSyncDate().then((value) => {
      setState(() {
        print("LastSync: $lastUpdate");
        lastUpdate = value ?? 'N/A';
      })
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: (){
              Provider.of<CategoryProvider>(context,listen: false)
                .initializeCategories();
            }, 
            icon: const Icon(Icons.refresh)
          ),

          IconButton(
            onPressed: () {
              Provider.of<CategoryProvider>(context, listen: false)
              .clearList();
            },
            icon: const Icon(Icons.delete),
          )
        ],

        title: const Text("TIPOS DE POKEMON"),
      ),
      
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 10),
            child: SizedBox(
              width: double.infinity,
              height: 40,
              child: Card(
                elevation: 10,
                child: Center(
                  child: Text("Ultima sincronizacion: $lastUpdate")
                )
              ),
            ),
          ),
          const Expanded(
            child: CategoryListWidget()
          )
        ]
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Provider.of<CategoryProvider>(context, listen: false)
              .addCategory("Fire");

          setState(() {
            lastUpdate = DateTime.now().toIso8601String();
            updateLastSyncDate(lastUpdate);
          });
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
